const { Telegraf } = require("telegraf");
const TOKEN = "7331706270:AAFLcRLR6xh5M8wVFE3Ays69cCqbaEHd09U";
const bot = new Telegraf(TOKEN);

const web_link = "https://66d1b7081638772b5f2dbd95--zabii.netlify.app/";

bot.start((ctx) =>
  ctx.reply("Welcome To My-Mini-App ;)", {
    reply_markup: {
      keyboard: [[{ text: "web app", web_app: { url: web_link } }]],
    },
  })
);

bot.launch();
